package cs245.as3;

import java.util.*;

import cs245.as3.driver.LogManagerImpl;
import cs245.as3.interfaces.LogManager;
import cs245.as3.interfaces.StorageManager;
import cs245.as3.interfaces.StorageManager.TaggedValue;

/**
 * You will implement this class.
 *
 * The implementation we have provided below performs atomic transactions but the changes are not durable.
 * Feel free to replace any of the data structures in your implementation, though the instructor solution includes
 * the same data structures (with additional fields) and uses the same strategy of buffering writes until commit.
 *
 * Your implementation need not be threadsafe, i.e. no methods of TransactionManager are ever called concurrently.
 *
 * You can assume that the constructor and initAndRecover() are both called before any of the other methods.
 */
public class TransactionManager {
	class WritesetEntry {
		public long key;
		public byte[] value;
		public WritesetEntry(long key, byte[] value) {
			this.key = key;
			this.value = value;
		}
	}
	/**
	  * Holds the latest value for each key.
	  */
	private HashMap<Long, TaggedValue> latestValues;
	/**
	  * Hold on to writesets until commit.
	  */
	private HashMap<Long, ArrayList<WritesetEntry>> writesets;

	/**
	 * key->txID; value->日志记录
	 */
	private HashMap<Long, ArrayList<LogRecord>> logRecordSets;

	private LogManager logManager;
	private StorageManager storageManager;

	//需要持久化的写事务对应的logRecord的尾部在logManager的偏移
	//保存为一个最小堆
	private PriorityQueue<Long> needPersistent;

	//延迟删除数组
	ArrayList<Long> deletedList;

	public TransactionManager() {
		writesets = new HashMap<>();
		latestValues = null;
		logRecordSets = new HashMap<>();
		needPersistent = new PriorityQueue<Long>();
		deletedList = new ArrayList<>();
	}

	/**
	 * Prepare the transaction manager to serve operations.
	 * At this time you should detect whether the StorageManager is inconsistent and recover it.
	 *
	 */
	public void initAndRecover(StorageManager sm, LogManager lm) {
		latestValues = sm.readStoredTable(); //得到已经持久化的数据 读取的时候判断了persisted_version是否为null

		this.logManager = lm;
		this.storageManager = sm;

		//读取从截断点开始到结束时的日志
		ArrayList<LogRecord> logRecords = new ArrayList<>();
		ArrayList<Long> offsets = new ArrayList<>(); //记录每条日志的偏移量
		ArrayList<Long> commitOff = new ArrayList<>();
		long offset = logManager.getLogTruncationOffset(); //获取截断点偏移量
		while(offset < logManager.getLogEndOffset()){
			LogRecord logRecord = LogRecord.readLogrecord(logManager,offset);
			logRecords.add(logRecord);
			offsets.add(offset);
			offset += logRecord.getSize();
			//记录下commit事务的ID，只需要恢复已经commit的事务
			if(logRecord.getType() == LogRecordType.commit){
				commitOff.add(logRecord.getTxID());
			}
		}

		for(int i = 0;i < logRecords.size();i++){
			LogRecord logRecord = logRecords.get(i);
			if(commitOff.contains(logRecord.getTxID()) && logRecord.getType() == LogRecordType.write) {
				//恢复有提交操作的写事务 且该写事务还没有持久化
				if(!deletedList.contains(logRecord.getTxID())){
					long tag = offsets.get(i);
					latestValues.put(logRecord.getKey(), new TaggedValue(tag, logRecord.getValue()));
					storageManager.queueWrite(logRecord.getKey(), tag, logRecord.getValue());
					needPersistent.add(logRecord.getTxID());
				}
			}
		}
	}

	/**
	 * Indicates the start of a new transaction. We will guarantee that txID always increases (even across crashes)
	 */
	public void start(long txID) {
		// TODO: Not implemented for non-durable transactions, you should implement this
	}

	/**
	 * Returns the latest committed value for a key by any transaction.
	 */
	public byte[] read(long txID, long key) {
		TaggedValue taggedValue = latestValues.get(key);
		return taggedValue == null ? null : taggedValue.value;
	}

	/**
	 * Indicates a write to the database. Note that such writes should not be visible to read() 
	 * calls until the transaction making the write commits. For simplicity, we will not make reads 
	 * to this same key from txID itself after we make a write to the key. 
	 */
	public void write(long txID, long key, byte[] value) {
		//写数据
		ArrayList<WritesetEntry> writeset = writesets.get(txID);
		if (writeset == null) {
			writeset = new ArrayList<>();
			writesets.put(txID, writeset);
		}
		writeset.add(new WritesetEntry(key, value));

		//写日志
		ArrayList<LogRecord> logRecordSet = logRecordSets.get(txID);
		if (logRecordSet == null) {
			logRecordSet = new ArrayList<>();
			logRecordSet.add(LogRecord.noWirte(LogRecordType.start,txID));
			logRecordSets.put(txID, logRecordSet);
		}
		logRecordSet.add(LogRecord.write(txID, key, value));
	}
	/**
	 * Commits a transaction, and makes its writes visible to subsequent read operations.\
	 */
	public void commit(long txID) {
		//持久化日志：将日志写入logManager
		ArrayList<LogRecord> logRecordSet = logRecordSets.get(txID);
		if(logRecordSet == null){
			return ;
		}
		logRecordSet.add(LogRecord.noWirte(LogRecordType.commit, txID));
		HashMap<Long, Long> keyToOffset = new HashMap<>();
		for(LogRecord logRecord : logRecordSet) {
			long offset = LogRecord.writeLogRecord(logManager, logRecord);
			if(logRecord.getType() == LogRecordType.write) {
				keyToOffset.put(logRecord.getKey(), offset);
			}
		}

		//持久化写数据，写入需要持久化的sm的属性中
		//真正持久化是在测试中调用sm的持久化函数实现的
		ArrayList<WritesetEntry> writeset = writesets.get(txID);
		if (writeset != null) {
			for(WritesetEntry x : writeset) {
				//tag is unused in this implementation:
				long offset = keyToOffset.get(x.key);
				latestValues.put(x.key, new TaggedValue(offset, x.value));
				storageManager.queueWrite(x.key, offset, x.value);
				needPersistent.add(offset);
			}
			writesets.remove(txID);
			logRecordSets.remove(txID);
		}
	}
	/**
	 * Aborts a transaction.
	 */
	public void abort(long txID) {
		needPersistent.remove(txID);
		writesets.remove(txID);
	}

	/**
	 * The storage manager will call back into this procedure every time a queued write becomes persistent.
	 * These calls are in order of writes to a key and will occur once for every such queued write, unless a crash occurs.
	 */
	public void writePersisted(long key, long persisted_tag, byte[] persisted_value) {
		long offset = -1;
		deletedList.add(persisted_tag);
		while(!needPersistent.isEmpty() && deletedList.contains(needPersistent.peek())){
			//更新截断点
			offset = needPersistent.poll();
			deletedList.remove(offset);
		}
		if(offset!=-1){
			logManager.setLogTruncationOffset((int) offset);
		}
	}
}
