package cs245.as3;

public class LogRecordType {
    public static final byte start = 0;
    public static final byte write = 1;
    public static final byte commit = 2;
    public static final byte rollback = 3;
}
