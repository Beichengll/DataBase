package cs245.as3;

import cs245.as3.interfaces.LogManager;

import java.nio.ByteBuffer;
import java.util.Arrays;

public class LogRecord {

    // 头部长度
    public static final int headLen = 13;
    // LogManager最大的byte数组长度
    public static final int maxLen = 128;

    private int size;
    private byte type;
    private long txID;
    private long key;
    byte[] value;

    public LogRecord(byte type, long txID) {
        this.type = type;
        this.txID = txID;
        this.size = headLen;
    }

    public LogRecord(byte type, long txID, long key, byte[] value) {
        this.type = type;
        this.txID = txID;
        this.key = key;
        this.value = value;
        this.size = headLen + 8 + value.length;
    }

    public LogRecord() {
    }

    public int getSize() {
        return size;
    }

    public byte getType() {
        return type;
    }

    public long getTxID() {
        return txID;
    }

    public long getKey() {
        return key;
    }

    public byte[] getValue() {
        return value;
    }

    @Override
    public String toString() {
        if(type == LogRecordType.write){
            return "LogRecord{" +
                    "size=" + size +
                    ", type=" + type +
                    ", txID=" + txID +
                    ", key=" + key +
                    ", value=" + Arrays.toString(value) +
                    '}';
        }else {
            return "LogRecord{" +
                    "size=" + size +
                    ", type=" + type +
                    ", txID=" + txID +
                    '}';
        }
    }

    //构造不同类型的日志记录
    public static LogRecord noWirte(byte type, long txID){
        return new LogRecord(type,txID);
    }
    public static LogRecord write(long txID, long key, byte[] value){
        return new LogRecord(LogRecordType.write, txID, key, value);
    }

    /**
     * 写入一条新的日志记录
     * @param lm
     * @param logRecord
     * @return 新的日志结尾偏移量
     */
    public static long writeLogRecord(LogManager lm, LogRecord logRecord) {
        int size =logRecord.getSize();
        ByteBuffer buffer = ByteBuffer.allocate(size);
        buffer.putInt(size);
        buffer.put(logRecord.getType());
        buffer.putLong(logRecord.getTxID());
        if(logRecord.getType() == LogRecordType.write){ //是写类型的话，存入key和value
            buffer.putLong(logRecord.getKey());
            buffer.put(logRecord.getValue()); //存入byte[]类型的value
        }
        //将buffer中的日志数据依次存入byte[] temp,每次最多存maxLen长度
        long tag = lm.getLogEndOffset(); //获取当前日志结尾偏移
        for(int i = 0;i < size;i += maxLen){
            int len = Math.min(size - i, maxLen);
            byte[] temp = new byte[len];
            for(int j = 0;j < len;j++){
                temp[j] = buffer.get(i+j);
            }
            lm.appendLogRecord(temp);
        }
        //返回写入日志后新的结尾偏移量
        return tag+size;
    }

    /**
     *读取一条日志并返回
     * @param lm
     * @param offset
     * @return
     */
    public static LogRecord readLogrecord(LogManager lm, long offset) {

        byte[] head = lm.readLogRecord((int)offset,headLen);
        int index = headLen; //当前日志偏移量索引
        int size = ByteToUtils.bytes2UnsignedInt(head,0);
        byte type = head[4];
        long txID = ByteToUtils.bytes2Long(head,5);
        if(type != LogRecordType.write){
            return new LogRecord(type,txID);
        }
        byte[] keyBytes = lm.readLogRecord((int)offset+index,8);
        index += 8;
        long key = ByteToUtils.bytes2Long(keyBytes,0);
        byte[] value = new byte[size-headLen-8];
        for(int i = 0;i < value.length;i += maxLen){
            int len = Math.min(size-index, maxLen);
            byte[] data = lm.readLogRecord((int)offset+index,len);
            System.arraycopy(data,0,value,i,len);
            index += len;
        }
        return new LogRecord(type,txID,key,value);
    }
}
