package cs245.as3;

public class ByteToUtils {
    /**
     * byte数组转换为int类型值；byte数组长度为4, bytes[3]为高8位
     *
     * @param bytes
     * @return
     */
    public static int bytes2UnsignedInt(byte[] bytes, int index) {
        int value = ((bytes[index] & 0xff) << 24) |
                ((bytes[index+1] & 0xff) << 16) |
                ((bytes[index+2] & 0xff) << 8) |
                (bytes[index+3] & 0xff);
        return value;
    }
    public static long bytes2Long(byte[] bytes,int index) {
        long value = 0;
        for(int i = 0;i < 8;i++){
            long num = bytes[index + i] < 0 ? (long) bytes[index + i] + 256L : (long) bytes[index + i];
            value += num << (56-8*i);
        }
        return value;
    }


}
