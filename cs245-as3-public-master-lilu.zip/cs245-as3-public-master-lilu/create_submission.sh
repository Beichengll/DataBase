rm student_submission.zip
zip -j student_submission.zip src/cs245/as3/*.java
